import React from "react";
import OCForm from "../../components/ordercompletecomponent/OCForm";

const OrderComplete = () => {
  return (
    <div>
      <OCForm />
    </div>
  );
};

export default OrderComplete;
