import React from "react";

const A = () => {
  return <div>A</div>;
};

export default A;
