import React from "react";

const CommunityPage = () => {
  return <div>CommunityPage</div>;
};

export default CommunityPage;
