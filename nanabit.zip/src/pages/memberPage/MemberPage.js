import React from "react";

const MemberPage = () => {
  return <div>MemberPage</div>;
};

export default MemberPage;
