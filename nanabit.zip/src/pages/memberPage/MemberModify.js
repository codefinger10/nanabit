import React from "react";

const MemberModify = () => {
  return <div>MemberModify</div>;
};

export default MemberModify;
