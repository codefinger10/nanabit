import React from "react";

const SerachTop = () => {
  return <div>SerachTop</div>;
};

export default SerachTop;
