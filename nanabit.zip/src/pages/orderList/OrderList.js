import React from "react";

const OrderList = () => {
  return <div>OrderList</div>;
};

export default OrderList;
