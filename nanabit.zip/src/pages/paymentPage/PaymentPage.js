import React from "react";
import Payment from "../../components/paymentpagecomponent/PaymentCom";

const PaymentPage = () => {
  return (
    <>
      {/* 결제창 */}
      <Payment />
    </>
  );
};
export default PaymentPage;
