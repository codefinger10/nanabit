import React from "react";

const MonthlyPage = () => {
  return <div>MonthlyPage</div>;
};

export default MonthlyPage;
