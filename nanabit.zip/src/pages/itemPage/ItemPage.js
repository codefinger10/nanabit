import React from "react";
import { ComTitle } from "../../styles/communitytitlestyle";

const ItemPage = () => {
  return (
    <div>
      <ComTitle />
    </div>
  );
};

export default ItemPage;
