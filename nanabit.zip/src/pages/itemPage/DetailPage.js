import React from "react";

const DetailPage = () => {
  return <div>DetailPage</div>;
};

export default DetailPage;
