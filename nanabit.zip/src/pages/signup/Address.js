import { Button, Form, Input, Modal } from "antd";
import React, { useEffect, useState } from "react";
import DaumPostcode from "react-daum-postcode";

const Address = () => {
  const [zodecode, setZonecode] = useState("");
  const [address, setAddress] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [detailedAddress, setDetailedAddress] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const themeObj = {
    bgColor: "#FFFFFF",
    pageBgColor: "#FFFFFF",
    postcodeTextColor: "#C05850",
    emphTextColor: "#222222",
  };

  const postCodeStyle = {
    width: "260px",
    height: "380px",
  };

  const completeHandler = data => {
    const { address, zonecode } = data;
    setZonecode(zonecode);
    setAddress(address);
    console.log(address, zonecode);
  };

  const closeHandler = state => {
    if (state === "FORCE_CLOSE") {
      setIsOpen(false);
    } else if (state === "COMPLETE_CLOSE") {
      setIsOpen(false);
    }
  };

  const toggleHandler = () => {
    setIsOpen(prevOpenState => !prevOpenState);

    setIsModalOpen(true);
  };
  const inputChangeHandler = event => {
    setDetailedAddress(event.target.value);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  return (
    <div>
      <Form.Item label="우편번호" name="zodecode">
        <Input value={zodecode} />
      </Form.Item>

      <Button type="button" onClick={toggleHandler}>
        주소 찾기
      </Button>
      {isOpen && (
        <Modal
          title="Basic Modal"
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
        >
          <DaumPostcode
            theme={themeObj}
            style={postCodeStyle}
            onComplete={completeHandler}
            onClose={closeHandler}
          />
        </Modal>
      )}

      <Form.Item label="주소" name="address">
        <Input type="text" value={address} />
      </Form.Item>

      <br />
      <Form.Item label="상세주소" name="detailedAddress">
        <Input value={detailedAddress} onChange={inputChangeHandler} />
      </Form.Item>
    </div>
  );
};

export default Address;
