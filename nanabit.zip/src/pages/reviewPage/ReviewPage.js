import React from "react";
import ReviewPageCom from "../../components/review/ReviewPageCom";

const ReviewPage = () => {
  return (
    <div>
      <ReviewPageCom />
    </div>
  );
};
export default ReviewPage;
