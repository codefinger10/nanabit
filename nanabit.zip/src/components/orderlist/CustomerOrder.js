import React from "react";

const headers = [
  {
    text: "orderdate",
    value: "orderdate",
  },
  {
    text: "이미지",
    value: "img",
  },
  {
    text: "Launch Date",
    value: "launch",
  },
  {
    text: "itemTittle",
    value: "itemT ittle",
  },
  {
    text: "pcs",
    value: "pcs",
  },
  {
    text: "pcs",
    value: "pcs",
  },
];
const CustomerOrder = () => {
  return (
    <table>
      <thead></thead>
      <tbody></tbody>
    </table>
  );
};

export default CustomerOrder;
