import React from "react";

const a = () => {
  return <header>a</header>;
};

export default a;
