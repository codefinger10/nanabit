import React from "react";

const BabyMealPage = () => {
  return <div>BabyMealPage</div>;
};

export default BabyMealPage;
