import React from "react";

const OrderComplete = () => {
  return <div>OrderComplete</div>;
};

export default OrderComplete;
