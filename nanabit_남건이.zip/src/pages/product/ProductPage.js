import React from "react";

import { Outlet } from "react-router";
import ProductLayout from "./ProductLayout";

const ProductPage = () => {
  return (
    <div>
      <ProductLayout />
    </div>
  );
};

export default ProductPage;
