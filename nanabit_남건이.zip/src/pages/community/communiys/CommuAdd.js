import React from "react";
import Reactquills from "../Reactquills";

const CommuAdd = () => {
  return (
    <>
      <Reactquills />
    </>
  );
};

export default CommuAdd;
