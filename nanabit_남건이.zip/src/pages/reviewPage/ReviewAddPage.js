import React from "react";
import ReviewAddPageCom from "../../components/review/ReviewAddCom";

const ReviewAddPage = () => {
  return (
    <div>
      <ReviewAddPageCom />
    </div>
  );
};

export default ReviewAddPage;
