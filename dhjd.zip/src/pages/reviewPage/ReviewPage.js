import React from "react";

const ReviewPage = () => {
  return <div>ReviewPage</div>;
};

export default ReviewPage;
